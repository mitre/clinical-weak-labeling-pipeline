# NLP with weak label pipeline

# How to use

Step #1:
set filepaths in "VIP_FilePaths.csv" to the correct paths for your system

Step #2:
run "concept_extraction_input_arguments.py"

Step #3:
run "concept_extraction_nlp_pipe.py"

Step #4:
run "concept_extraction_SnorkelPipe.py"